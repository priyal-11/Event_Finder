import React, { useContext } from "react";
import { LanguageContext } from "./language";

const translations = {
  title: { en: "Privacy Policy", es: "Política de Privacidad" },
  content: {
    en: [
      "1. Introduction: At EventFinder, we respect your privacy ...",
      "2. Data collection: We collect personal information ...",
      "3. Use of Data: Your data helps us recommend events ...",
      "4. Security: We use security measures to protect your information ...",
      "5. Your rights: You can update or delete your information ...",
      "6. Contact: For questions, contact us at [support@eventfinderapp.com]."
    ],
    es: [
      "1. Introducción: En EventFinder, respetamos tu privacidad ...",
      "2. Recopilación de datos: Recopilamos información personal ...",
      "3. Uso de datos: Tus datos nos ayudan a recomendar eventos ...",
      "4. Seguridad: Utilizamos medidas de seguridad para proteger tu información ...",
      "5. Tus derechos: Puedes actualizar o eliminar tu información ...",
      "6. Contacto: Para preguntas, contáctanos en [soporte@eventfinderapp.com]."
    ]
  },
};

const PrivacyPolicy = () => {
  const { language } = useContext(LanguageContext);

  return (
    <div style={{ padding: "20px" }}>
      <h1>{translations.title[language]}</h1>
      {translations.content[language].map((paragraph, index) => (
        <p key={index}>{paragraph}</p>
      ))}
    </div>
  );
};

export default PrivacyPolicy;

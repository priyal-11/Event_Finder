const users = require("./users");
const events = require("./event");
const user_favourite_events = require("./user_favourite_events");
const purchase = require("./purchase");

module.exports = {
  users,
  events,
  user_favourite_events,
  purchase,
};

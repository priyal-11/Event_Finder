import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./components/language"; 
import Navbar from "./components/navbar";
import Footer from "./components/footer";
import EventList from "./components/eventlist";
import SignUp from "./components/signup";
import Login from "./components/login";
import EventDetails from "./components/eventdetail";
import UserDashboard from "./components/userdashboard";
import PaymentPage from "./components/payment";
import PaymentSuccessPage from "./components/paymentsuccess";
import CreateEventPage from "./components/eventCreate";
import About from "./components/about";  
import Contact from "./components/contact";  
import PrivacyPolicy from "./components/privacyPolicy"; 
import NotFound from "./components/notFound";
import "./App.css";

function App() {
  return (
    <LanguageProvider>
      <Router>
        <div className="App">
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<EventList />} />
              <Route path="/event/:id" element={<EventDetails />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/user-dashboard" element={<UserDashboard />} />
              <Route path="/payment" element={<PaymentPage />} />
              <Route path="/payment-success" element={<PaymentSuccessPage />} />
              <Route path="/create-event" element={<CreateEventPage />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/privacy-policy" element={<PrivacyPolicy />} />
              <Route path="/*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </LanguageProvider>
  );
}

export default App;

import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import { LanguageContext } from "./language";
import "./signup.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const translations = {
  title: { en: "Sign Up", es: "Registrarse" },
  firstname: { en: "First Name", es: "Nombre" },
  lastname: { en: "Last Name", es: "Apellido" },
  email: { en: "Email", es: "Correo Electrónico" },
  password: { en: "Password", es: "Contraseña" },
  confirmPassword: { en: "Re-type Password", es: "Reingresar Contraseña" },
  buttonText: { en: "Register", es: "Registrarse" },
  loginText: { en: "Already have an account? Login", es: "¿Ya tienes una cuenta? Iniciar Sesión" },
  passwordMismatch: { en: "Passwords do not match", es: "Las contraseñas no coinciden" },
  passwordLength: { en: "Please choose a password with 8 or more characters", es: "Elija una contraseña con 8 o más caracteres" },
  emailFormat: { en: "The email should contain '@' and a valid domain", es: "El correo electrónico debe contener '@' y un dominio válido" },
};

const SignUp = () => {
  const { language } = useContext(LanguageContext);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    // Clear errors when user starts typing again
    setError("");
  };

  const validateForm = () => {
    const { email, password, confirmPassword } = formData;

    // Check if password is at least 8 characters
    if (password.length < 8) {
      setError(translations.passwordLength[language]);
      return false;
    }

    // Check if email contains an '@' symbol and a domain
    if (!email.includes("@") || !email.split("@")[1]) {
      setError(translations.emailFormat[language]);
      return false;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
      setError(translations.passwordMismatch[language]);
      return false;
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate form inputs before submission
    if (!validateForm()) {
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/users/signup", formData, {
        headers: { "Content-Type": "application/json" },
      });

      if (response?.data?.status) {
        navigate("/login");
      } else {
        setError(response?.data?.message || "Signup failed. Please try again.");
      }
    } catch (error) {
      console.error("Signup error:", error);
      setError("An error occurred during signup. Please try again.");
    }
  };

  return (
    <div className="signup-page">
      <div className="form-container">
        <h2 className="form-title">{translations.title[language]}</h2>
        <form className="signup-form" onSubmit={handleSubmit}>
          <label htmlFor="firstname">{translations.firstname[language]}</label>
          <input
            type="text"
            id="firstname"
            name="firstname"
            onChange={handleChange}
            required
          />
          <label htmlFor="lastname">{translations.lastname[language]}</label>
          <input
            type="text"
            id="lastname"
            name="lastname"
            onChange={handleChange}
            required
          />
          <label htmlFor="email">{translations.email[language]}</label>
          <input
            type="text" // Change to text to apply custom validation
            id="email"
            name="email"
            onChange={handleChange}
            required
          />
          <label htmlFor="password">{translations.password[language]}</label>
          <input
            type="password"
            id="password"
            name="password"
            onChange={handleChange}
            required
          />
          <label htmlFor="confirmPassword">
            {translations.confirmPassword[language]}
          </label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            onChange={handleChange}
            required
          />

          {/* Display error message if it exists */}
          {error && <p className="error-message">{error}</p>}

          <button type="submit" className="register-button">
            {translations.buttonText[language]}
          </button>
        </form>
        <div className="login-link">
          <Link to="/login">{translations.loginText[language]}</Link>
        </div>
      </div>

      {/* Right side image container */}
      <div className="image-container">
        <img src="/images/register.jpg" alt="Sign up visual" />
      </div>
    </div>
  );
};

export default SignUp;

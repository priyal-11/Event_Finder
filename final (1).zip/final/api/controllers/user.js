const db = require("../models");
const _ = require("lodash");

const {
  verifyPassword,
  generateJWTToken,
} = require("../utils/common_functions");

const userModel = db.users;

module.exports.signup = async (req, res) => {
  try {
    const { firstname, lastname, email, password } = req?.body;

    const userData = {
      firstname,
      lastname,
      email,
      password,
    };

    const createUser = await userModel
      .create(userData)
      .then(() => {
        return { status: true, message: "Signup successfully." };
      })
      .catch((error) => {
        return { status: false, message: error?.message };
      });

    return res.status(200).send(createUser);
  } catch (error) {
    return res.status(500).send({ status: false, messaage: error?.message });
  }
};

module.exports.login = async (req, res) => {
  try {
    const { email, password } = req?.body;

    const findUserByEmail = await userModel.findOne({ email: email });

    if (!_.isEmpty(findUserByEmail)) {
      const isPasswordMatch = await verifyPassword(
        password,
        findUserByEmail?.password
      );

      if (isPasswordMatch) {
        const token = generateJWTToken({ payload: findUserByEmail });
        return res.status(200).send({
          status: true,
          data: { auth_token: token },
          message: "Login successfully.",
        });
      } else {
        return res.status(200).send({
          status: false,
          message: "Incorrect password.",
        });
      }
    } else {
      return res.status(200).send({
        status: false,
        message: "User not found using this email, please signup first.",
      });
    }
  } catch (error) {
    return res.status(500).send({ status: false, messaage: error?.message });
  }
};

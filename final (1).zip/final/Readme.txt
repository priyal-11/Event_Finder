How to run the Application 

Running the Event Finder application is a straightforward process. Here are the simple steps to get started.
1.	First, Unzip the Event Finder zip file.
2.	Then, you will get two folders: events and API. 
3.	Also, you have 4 JSON files for the database. 
4.	The event folder has all the front-end code, and the API has all the back-end-side code.  
5.	Open both folders in different vs. code windows. 
6.	Then open the terminal and write the command npm i to install the node modules.   
7.	We have provided 4 JSON files for the database tables for your convenience. To access them, simply open the MongoDB compass and connect to the database. 
8.	Then, you have localhost:27017 written on the left-hand side. Hover over it, press the plus sign, and write the database name (event_planner) and collection name users. 
9.	Add other collections by pressing the plus sign at the event planner and add other tables (events, purchases, user_favourite_events).
10.	 Now press on the collection name, and at the top bar, press add data and add the JSON files. 
11.	 Now go to the home screen, press the login button, and enter the username and password. 
Admin user username- admin @gmail.com password -Pandya@17
Regular Username – mpandya1@gmail.com password – Pandya@17  
pshah@gmail.com password - Shah@12345 
12.	When you log in as admin, you can see the Create Event button. Press it, and the Create Event page will open. There, you must enter the event details and press the Create Event button.
13.	 You can see the event created on the home page. 
14.	 Now, you can log in as a regular user using the above credentials or create a new user and then log in. 
15.	 Now, the user can press in the events, see the details, and sort them using the drop-down menu at the top right corner according to category. 
16.	 On the event detail page, the user can see the details and select the number of tickets for the event. Then press the Book Now button, and the user is directed to the dashboard where he can see pending tickets remaining to buy.
17.	The user must select the ticket he wants to buy from the check box and can also delete the one he does not want to buy.
18.	 Select the check box and click on the confirm to pay button. The user is directed to the payment page, where they enter their card details and press the pay button.
19.	The user will be redirected to the home screen in 10 seconds. 
20.	Press the purchased ticket button on the navigation bar to see the pending payment and booked events. 
21.	Pending payment will show the events that remain to be paid, and booked will show the ones that have been paid. 
22.	The About Us, Contact Us, and Privacy Policy pages are located below in the footer. 
23.	Also, the footer has a button on the bottom right corner to change the language.
24.	EN stands for English, and ES stands for Spanish. The language will change for all the texts. 
25.	Users can also like and share the event from the bottom of the card view on the home screen.
26.	At last, the user can log out of the system. 

const db = require("../models");
const _ = require("lodash");

const purchaseModel = db.purchase;
const eventsModel = db.events;

module.exports.purchase = async (req, res) => {
  try {
    const { _id: user_id } = req?.user;
    const { event_id, person, price } = req?.body;

    const findAlreadyPurcahse = await purchaseModel.findOne({
      user_id: user_id,
      event_id: event_id,
    });

    if (!_.isEmpty(findAlreadyPurcahse)) {
      const newPerson =
        parseInt(findAlreadyPurcahse?.person) + parseInt(person);
      const updatePurchaseData = {
        person: newPerson,
        price: newPerson * price,
      };

      const updatePurchase = await purchaseModel
        .updateOne({ _id: findAlreadyPurcahse?._id }, updatePurchaseData)
        .then(() => {
          return { status: true, message: "Event book successfully." };
        })
        .catch((error) => {
          return { status: false, message: error?.message };
        });

      res.status(200).send(updatePurchase);
    } else {
      const newPurchase = {
        user_id,
        event_id,
        person,
        price: person * price,
      };

      const savedPurchase = await purchaseModel
        .create(newPurchase)
        .then(() => {
          return { status: true, message: "Event book successfully." };
        })
        .catch((error) => {
          return { status: false, message: error?.message };
        });

      res.status(200).send(savedPurchase);
    }
  } catch (error) {
    res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.getPurchaseHistory = async (req, res) => {
  try {
    const { _id: user_id } = req?.user;
    const { type } = req?.params;

    const findEventsData = {
      user_id: user_id,
    };

    findEventsData.is_payment_complete = type === "pending" ? false : true;

    const purchaseHistory = await purchaseModel.find(findEventsData).lean();

    if (!_.isEmpty(purchaseHistory)) {
      const findEvent = await Promise.all(
        purchaseHistory.map(async (event) => {
          const eventData = await eventsModel
            .findById(event.event_id)
            .select("title spanishTitle date location price");

          if (!_.isEmpty(eventData)) {
            event.title = eventData.title; 
            event.spanishTitle = eventData.spanishTitle;
            event.location = eventData.location;
            event.date = eventData.date;

            return event;
          } else {
            return res
              .status(200)
              .send({ status: false, message: "Event not found." });
          }
        })
      );
      
      return res.status(200).send({
        status: true,
        data: findEvent,
        message: "User purchase history successfully found.",
      });
    } else {
      return res
        .status(200)
        .send({ status: false, message: "No purchase history found." });
    }
  } catch (error) {
    res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.delete = async (req, res) => {
  try {
    const { history_id } = req?.body;

    const deleteHistory = await purchaseModel
      .deleteOne({ _id: history_id })
      .then(() => {
        return {
          status: true,
          message: "Purchase history deleted successfully.",
        };
      })
      .catch((error) => {
        return { status: false, message: error?.message };
      });

    return res.status(200).send(deleteHistory);
  } catch (error) {
    res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.bookEvents = async (req, res) => {
  try {
    const { _id: user_id } = req?.user;
    const { event_ids } = req?.body;

    const findEventsData = {
      user_id: user_id,
      event_id: { $in: event_ids },
    };

    const updateData = {
      is_payment_complete: true,
    };

    const result = await purchaseModel.updateMany(findEventsData, {
      $set: updateData,
    });

    if (result.modifiedCount > 0) {
      res.status(200).send({
        status: true,
        message: "Events successfully booked.",
      });
    } else {
      res.status(200).send({
        status: false,
        message: "No events found to update.",
      });
    }
  } catch (error) {
    res.status(500).send({ status: false, message: error?.message });
  }
};

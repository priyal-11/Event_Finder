const jwt = require("jsonwebtoken");
const _ = require("lodash");
require("dotenv").config();

const app_secret = process.env.APP_SECRET;
const db = require("../models");

const userModel = db.users;

module.exports = async (req, res, next) => {
  try {
    const Authorization =
      req.headers["authorization"]?.split("Bearer ")[1] || null;

    if (Authorization !== null) {
      const secretKey = app_secret;

      await jwt.verify(Authorization, secretKey, async function (err, decoded) {
        if (err !== null) {
          return res.status(402).send({
            status: false,
            message: err.message,
            code: 402,
            module: "user",
          });
        }
        if (decoded) {
          req.user = decoded?.payload;

          const findUser = await userModel.findById(decoded?.payload?._id);

          if (!_.isEmpty(findUser) && findUser?.status == "-1") {
            return res.status(402).send({
              status: false,
              message: "User deactivate.",
            });
          }

          if (!findUser) {
            return res.status(402).send({
              status: false,
              message: "User not exist.",
            });
          }
          next();
        } else {
          return res.status(402).send({
            status: false,
            message: "You are not authorized.",
          });
        }
      });
    } else {
      return res.status(402).send({
        status: false,
        message: "Token not found.",
      });
    }
  } catch (error) {
    return res
      .status(500)
      .send({ status: false, message: error.message, code: 500 });
  }
};

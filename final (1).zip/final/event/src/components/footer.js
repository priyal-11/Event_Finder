import React, { useContext } from 'react';
import { LanguageContext } from './language';  // Import LanguageContext
import './footer.css';

const translations = {
  aboutUs: {
    en: 'About Us',
    es: 'Sobre Nosotros',
  },
  contactUs: {
    en: 'Contact Us',
    es: 'Contáctanos',
  },
  privacyPolicy: {
    en: 'Privacy Policy',
    es: 'Política de Privacidad',
  },
  copyright: {
    en: '@Copyright, all rights reserved 2024',
    es: '@Derechos de autor, todos los derechos reservados 2024',
  },
};

const Footer = () => {
  const { language, toggleLanguage } = useContext(LanguageContext);  // Access the language and toggle function

  return (
    <footer className="footer">
      <div>
        <a href="/about">{translations.aboutUs[language]}</a>  {/* Dynamic text */}
        <a href="/contact">{translations.contactUs[language]}</a>  {/* Dynamic text */}
        <a href="/privacy-policy">{translations.privacyPolicy[language]}</a>  {/* Dynamic text */}
        <p>{translations.copyright[language]}</p>  {/* Dynamic copyright */}
      </div>
      <div className="language-switcher">
        <button
          className={`language-btn ${language === 'en' ? 'active' : ''}`}
          onClick={() => toggleLanguage('en')}
        >
          EN
        </button>
        <button
          className={`language-btn ${language === 'es' ? 'active' : ''}`}
          onClick={() => toggleLanguage('es')}
        >
          ES
        </button>
      </div>
    </footer>
  );
};

export default Footer;

import React, { useContext, useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { LanguageContext } from "./language";
import { Carousel } from "react-responsive-carousel";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart, faShareAlt } from "@fortawesome/free-solid-svg-icons";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import "./eventlist.css";
import axios from "axios";
import { useSelector } from "react-redux";


const translations = {
  availableEvents: { en: "Available Events", es: "Eventos Disponibles" },
  selectCategory: { en: "Select Category", es: "Seleccionar Categoría" },
  category: {
    en: {
      All: 'All',
      sports: 'Sports',
      music: 'Music',
      dance: 'Dance',
      carnival: 'Carnival',
      art: 'Art',
    },
    es: {
      All: 'Todas',
      sports: 'Deportes',
      music: 'Música',
      dance: 'Danza',
      carnival: 'Carnaval',
      art: 'Arte',
    },
  },
};

const carouselImages = [
  "/images/art 3.jpg",
  "/images/carnival 1.jpg",
  "/images/dance 1.jpg",
  "/images/music 1.jpg",
  "/images/sport 2.jpg",
];

const EventList = () => {
  const { language } = useContext(LanguageContext);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [events, setEvents] = useState([]);
  const location = useLocation();
  const token = useSelector((state) => state.auth.token);

  const searchParams = new URLSearchParams(location.search);
  const searchTerm = searchParams.get("search") || "";

  const fetchEvents = async () => {
    try {
      const url = token
        ? "http://localhost:5000/events/get-events-for-login-users"
        : "http://localhost:5000/events/get-events";

      const response = await axios.post(url, {}, { headers: { Authorization: `Bearer ${token}` } });

      if (response?.data?.status) {
        setEvents(response.data.data);
      } else {
        console.error("Error fetching events:", response.data.message);
      }
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };

  const handleFavorite = async (eventId, event) => {
    event.stopPropagation();
    try {
      const response = await axios.post(
        "http://localhost:5000/events/like",
        { event_id: eventId },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response?.data?.status) {
        
        fetchEvents();
      } else {
        console.error("Error liking event:", response.data.message);
        
      }
    } catch (error) {
      console.error("Error liking event:", error);

    }
  };

  const handleShare = (event, eventId) => {
    event.stopPropagation();
    const shareUrl = `${window.location.href}event/${eventId}`;
    if (navigator.share) {
      navigator.share({
        title: "Check out this event!",
        url: shareUrl,
      });
    } else {
      navigator.clipboard.writeText(shareUrl);
      alert("Event link copied to clipboard!");
    }
  };

  useEffect(() => {
    fetchEvents();
  }, [token]);

  const filteredEvents = events.filter((event) => {
    const matchesCategory =
      selectedCategory === "All" || event.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearchTerm = event.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearchTerm;
  });

  return (
    <div className="event-list-container">
      <div className="carousel-section">
        <Carousel autoPlay infiniteLoop showThumbs={false}>
          {carouselImages.map((image, index) => (
            <div key={index} className="carousel-image-wrapper">
              <img src={image} alt={`Carousel ${index + 1}`} className="carousel-image" />
            </div>
          ))}
        </Carousel>
      </div>

      <div className="main-content">
        <div className="header-section">
          <h2 className="heading">{translations.availableEvents[language]}</h2>
          <div className="category-dropdown">
            <label htmlFor="category-select">
              {translations.selectCategory[language]}:
            </label>
            <select
              id="category-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              
          <option value="All">
              {translations.category[language]['All']}
            </option>    
          <option value="sports">
              {translations.category[language]['sports']}
            </option>
            <option value="music">
              {translations.category[language]['music']}
            </option>
            <option value="dance">
              {translations.category[language]['dance']}
            </option>
            <option value="carnival">
              {translations.category[language]['carnival']}
            </option>
            <option value="art">
              {translations.category[language]['art']}
            </option>
            </select>
          </div>
        </div>

        <div className="event-list">
          {filteredEvents.map((event) => (
            <div className="event" key={event._id}>
              <Link to={`/event/${event._id}`}>
                <img
                  src={"http://localhost:5000/" + event.image}
                  alt={event.title}
                  className="event-image"
                />
              </Link>
              <Link to={`/event/${event._id}`}>
              <h3>{language === 'es' ? event.spanishTitle : event.title}</h3>
              </Link>

              <div className="event-actions">
                {token && (
                  <FontAwesomeIcon
                    icon={faHeart}
                    className={`icon favorite-icon ${event?.isFavourite ? "favorited" : ""}`}
                    onClick={(e) => handleFavorite(event._id, e)}
                  />
                )}
                <FontAwesomeIcon
                  icon={faShareAlt}
                  className="icon share-icon"
                  onClick={(e) => handleShare(e, event._id)}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventList;

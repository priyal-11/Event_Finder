import React, { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./eventdetail.css";
import { LanguageContext } from "./language"; // Correct import of LanguageContext
import axios from "axios";
import { useSelector } from "react-redux";

const translations = {
  description: { en: "Description", es: "Descripción" },
  date: { en: "Date", es: "Fecha" },
  price: { en: "Price", es: "Precio" },
  location: { en: "location", es: "Ubicación" },
  selectTickets: { en: "Select Tickets", es: "Seleccionar Entradas" },
  ticket: { en: "Ticket", es: "Entrada" },
  bookNow: { en: "Book Now", es: "Reservar Ahora" },
};


const EventDetailsPage = () => {
  const { id } = useParams();
  const { language } = useContext(LanguageContext); // Accessing language context
  const navigate = useNavigate();
  const [tickets, setTickets] = useState(1);
  const [eventData, setEventData] = useState({});
  const token = useSelector((state) => state.auth.token);

  // Auto-scroll to the specified position when the page is loaded
  useEffect(() => {
    window.scrollTo({
      top: 300, // Scroll to 300px on Y-axis
      behavior: "smooth", // Smooth scrolling
    });
  }, []); // This hook is unconditionally called

  useEffect(() => {
    const fetchEventDetails = async () => {
      try {
        const response = await axios.post(
          "http://localhost:5000/events/event-detail",
          { event_id: id },
          {}
        );

        if (response?.data?.status) {
          setEventData(response.data.data);
        } else {
          console.error("Error fetching event details:", response.data.message);
        }
      } catch (error) {
        console.error("Error fetching events:", error);
      }
    };

    fetchEventDetails();
  }, []);

  const handleBookNow = async () => {
    const response = await axios.post(
      "http://localhost:5000/purchase/purchase",
      {
        event_id: id,
        person: tickets,
        price: eventData?.price?.$numberDecimal,
      },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    if (response?.data?.status) {
      navigate("/user-dashboard");
    } else {
      console.error("Error purchasing tickets:", response.data.message);
    }
  };

  return (
    <div className="event-details-container">
      <h1 className="page-title">{language === 'es' ? eventData.spanishTitle : eventData.title}</h1>

      <div className="event-card">
        <img
          src={"http://localhost:5000/" + eventData.image}
          alt={eventData.title}
          className="event-image"
        />
        <div className="details-container">
          <p>
            <b> {translations.description[language]}:</b>
            {language === 'es'
              ? eventData.spanishDescription
              : eventData.description}
          </p>
          <p>
            <b>{translations.location[language]}: </b>
            {eventData.location}
          </p>
          <p>
            <b>{translations.date[language]}: </b>
            {eventData.date}
          </p>
          <p>
            <b>{translations.price[language]}: </b>${eventData.price?.$numberDecimal}
          </p>

          {/* Ticket Selection Dropdown */}
          <div className="ticket-selection">
            <label htmlFor="tickets" className="ticket-label">
            {translations.selectTickets[language]}
            </label>
            <select
              id="tickets"
              value={tickets}
              onChange={(e) => setTickets(e.target.value)}
              className="ticket-dropdown"
            >
              <option value="1">1 {translations.ticket[language]}</option>
              <option value="2">2 {translations.ticket[language]}</option>
              <option value="3">3 {translations.ticket[language]}</option>
              <option value="4">4 {translations.ticket[language]}</option>
              <option value="5">5 {translations.ticket[language]}</option>
            </select>
          </div>

           {/* Book Now Button */}
           {token ? (
            <div className="button-container">
              <button className="book-now-button" onClick={handleBookNow}>
                {language === "en" ? "BOOK NOW" : "RESERVAR AHORA"}
              </button>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    </div>
  );
};

export default EventDetailsPage;




const mongoose = require("mongoose");

const userfavouriteEventsSchema = new mongoose.Schema(
  {
    user_id: {
      type: String,
      required: [true, "User id is required."],
      trim: true,
    },
    event_id: {
      type: String,
      required: [true, "Event id is required."],
      trim: true,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Export the User model
const UserFavouriteEvents = mongoose.model(
  "user_favourite_events",
  userfavouriteEventsSchema
);
module.exports = UserFavouriteEvents;

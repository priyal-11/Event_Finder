import React, { useState, useContext } from "react";
import { Link } from "react-router-dom";
import { LanguageContext } from "./language";
import axios from "axios";
import "./login.css";
import { useDispatch } from "react-redux";
import { setToken } from "../redux/authSlice";
import { useNavigate } from "react-router-dom";

const translations = {
  title: { en: "Login", es: "Iniciar Sesión" },
  username: { en: "Username", es: "Nombre de Usuario" },
  password: { en: "Password", es: "Contraseña" },
  buttonText: { en: "Login", es: "Iniciar Sesión" },
  signupText: { en: "Don't have an account? Sign Up", es: "¿No tienes una cuenta? Regístrate" },
};

const Login = () => {
  const { language } = useContext(LanguageContext);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [errorMessage, setErrorMessage] = useState(""); // State for error message

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage(""); // Clear any previous error message

    try {
      const response = await axios.post("http://localhost:5000/users/login", formData, {
        headers: { "Content-Type": "application/json" },
      });

      if (response?.data?.status) {
        dispatch(setToken(response.data.data.auth_token));
        navigate("/");
      } else {
        setErrorMessage(response?.data?.message || "Invalid login credentials");
      }
    } catch (error) {
      console.error("Login error:", error);
      setErrorMessage("An error occurred while logging in. Please try again.");
    }
  };

  return (
    <div className="login-page">
      <div className="form-container">
        <h2 className="form-title">{translations.title[language]}</h2>
        <form className="login-form" onSubmit={handleSubmit}>
          <label htmlFor="email">{translations.username[language]}</label>
          <input
            type="text"
            id="email"
            name="email"
            onChange={handleChange}
            required
          />
          <label htmlFor="password">{translations.password[language]}</label>
          <input
            type="password"
            id="password"
            name="password"
            onChange={handleChange}
            required
          />
          <button type="submit" className="login-button">
            {translations.buttonText[language]}
          </button>

          {/* Display error message if it exists */}
          {errorMessage && <p className="error-message">{errorMessage}</p>}
        </form>
        <div className="signup-link">
          <Link to="/signup">{translations.signupText[language]}</Link>
        </div>
      </div>

      {/* Image container on the right */}
      <div className="image-container">
        <img src="/images/login.jpg" alt="Login Visual" />
      </div>
    </div>
  );
};

export default Login;

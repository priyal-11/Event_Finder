const mongoose = require("mongoose");

const purchaseSchema = new mongoose.Schema(
  {
    user_id: {
      type: String,
      required: [true, "User id is required."],
      trim: true,
    },
    event_id: {
      type: String,
      required: [true, "Event id is required."],
      trim: true,
    },
    person: {
      type: String,
      required: [true, "Person is required"],
      trim: true,
    },
    price: {
      type: mongoose.Schema.Types.Decimal128,
      required: [true, "Price is required"],
      trim: true,
    },
    is_payment_complete: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Export the User model
const Purchase = mongoose.model("Purchase", purchaseSchema);
module.exports = Purchase;

import React from 'react';

const NotFound = () => {
  return <div style={{textAlign:"center"}}><img style={{height:"30%", width:"30%"}} src="https://firebasestorage.googleapis.com/v0/b/cloude-ide-96b39.appspot.com/o/mit-img%2Fnot-found.jpg?alt=media&token=2cb5017d-1920-4775-a6df-eaac6fa643f7" alt="Not Found" /></div>;
};


export default NotFound;
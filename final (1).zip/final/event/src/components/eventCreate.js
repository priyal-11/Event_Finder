import React, { useState, useContext } from 'react';
import axios from 'axios';
import { LanguageContext } from './language';
import './eventCreate.css';
import { useSelector } from 'react-redux';

const translations = {
  category: {
    en: {
      sports: 'Sports',
      music: 'Music',
      dance: 'Dance',
      carnival: 'Carnival',
      art: 'Art',
    },
    es: {
      sports: 'Deportes',
      music: 'Música',
      dance: 'Danza',
      carnival: 'Carnaval',
      art: 'Arte',
    },
  },
};

const EventForm = () => {
  const token = useSelector(state => state.auth.token);
  const { language } = useContext(LanguageContext);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    location: '',
    price: '',
    image: null,
    category: 'sports',
    spanishTitle: '',
    spanishDescription: '',
  });

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileChange = e => {
    setFormData({
      ...formData,
      image: e.target.files[0],
    });
  };

  const handleSubmit = async e => {
    e.preventDefault();

    // Create FormData object and append each field
    const data = new FormData();
    data.append('title', formData.title);
    data.append('description', formData.description);
    data.append('date', formData.date);
    data.append('location', formData.location);
    data.append('price', formData.price);
    data.append('event_image', formData.image); // File field
    data.append('category', formData.category);
    data.append('spanishTitle', formData.spanishTitle);
    data.append('spanishDescription', formData.spanishDescription);

    try {
      // Example of sending form data to server (update the URL as needed)
      const response = await axios.post(
        'http://localhost:5000/events/create',
        data,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log('response', response);
      if (response?.data?.status) {
        setFormData({
          title: '',
          description: '',
          date: '',
          location: '',
          price: '',
          image: null,
          category: 'sports',
          spanishDescription: '',
          spanishTitle: '',
        });
      } else {
        console.error('Error creating event:', response?.data?.message);
      }
    } catch (error) {
      console.error('Error creating event:', error);
    }
  };

  return (
    <div className="event-form">
      <h2>Create Event</h2>
      <form onSubmit={handleSubmit}>
        {/* Title */}
        <label>
          Title:
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Title in Spanish:
          <input
            type="text"
            name="spanishTitle"
            value={formData.spanishTitle}
            onChange={handleChange}
            required
          />
        </label>

        {/* Description */}
        <label>
          Description:
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Description in Spanish:
          <textarea
            name="spanishDescription"
            value={formData.spanishDescription}
            onChange={handleChange}
            required
          />
        </label>

        {/* Date */}
        <label>
          Date:
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </label>

        {/* Location */}
        <label>
          Location:
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleChange}
            required
          />
        </label>

        {/* Price */}
        <label>
          Price:
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleChange}
            required
          />
        </label>

        {/* Image (File Upload) */}
        <label>
          Image:
          <input
            type="file"
            name="image"
            onChange={handleFileChange}
            accept="image/*"
            required
          />
        </label>

        {/* Category (Dropdown) */}
        <label>
          Category:
          <select
            name="category"
            value={formData.category}
            onChange={handleChange}
          >
            <option value="sports">
              {translations.category[language]['sports']}
            </option>
            <option value="music">
              {translations.category[language]['music']}
            </option>
            <option value="dance">
              {translations.category[language]['dance']}
            </option>
            <option value="carnival">
              {translations.category[language]['carnival']}
            </option>
            <option value="art">
              {translations.category[language]['art']}
            </option>
          </select>
        </label>

        {/* Submit Button */}
        <button type="submit">Create Event</button>
      </form>
    </div>
  );
};

export default EventForm;

const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required.'],
      trim: true,
    },
    spanishTitle: {
      type: String,
      required: [true, 'Spanish Title is required.'],
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Description is required.'],
      trim: true,
    },
    spanishDescription: {
      type: String,
      required: [true, 'Spanish Description is required.'],
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Location is required.'],
      trim: true,
    },
    date: {
      type: String,
      required: [true, 'Date is required.'],
      trim: true,
    },
    price: {
      type: mongoose.Schema.Types.Decimal128,
      required: [true, 'Price is required'],
      trim: true,
    },
    image: {
      type: String,
    },
    category: {
      type: String,
      required: [true, 'Category is required.'],
      trim: true,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Export the Event model
const Event = mongoose.model('Event', eventSchema);
module.exports = Event;

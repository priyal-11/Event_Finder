import React, { createContext, useState, useEffect } from "react";

// Create a context for language management
export const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
    // Load language from localStorage or default to English
    const [language, setLanguage] = useState(localStorage.getItem("language") || "en");

    // Save language to localStorage whenever it changes
    useEffect(() => {
        localStorage.setItem("language", language);
    }, [language]);

    // Toggle language function
    const toggleLanguage = () => {
        setLanguage((prevLang) => (prevLang === "en" ? "es" : "en"));
    };

    return (
        <LanguageContext.Provider value={{ language, toggleLanguage }}>
            {children}
        </LanguageContext.Provider>
    );
};

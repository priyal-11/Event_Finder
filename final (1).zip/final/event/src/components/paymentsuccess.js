import React, { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { LanguageContext } from "./language";
import "./paymentsuccess.css";

const translations = {
  title: { en: "Payment Successful", es: "Pago Exitoso" },
  message: {
    en: "Thank you for your payment! You will be redirected to the event list in",
    es: "¡Gracias por tu pago! Serás redirigido a la lista de eventos en"
  },
  seconds: { en: "seconds.", es: "segundos." },
};

const PaymentSuccessPage = () => {
  const navigate = useNavigate();
  const { language } = useContext(LanguageContext);
  const [secondsLeft, setSecondsLeft] = useState(10);

  useEffect(() => {
    const interval = setInterval(() => {
      setSecondsLeft((prev) => prev - 1);
    }, 1000);

    if (secondsLeft === 0) {
      navigate("/");
    }

    return () => clearInterval(interval);
  }, [secondsLeft, navigate]);

  return (
    <div className="payment-success-container">
      <h1>{translations.title[language]}</h1>
      <p>{translations.message[language]} {secondsLeft} {translations.seconds[language]}</p>
    </div>
  );
};

export default PaymentSuccessPage;

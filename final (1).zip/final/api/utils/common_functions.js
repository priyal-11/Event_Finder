const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const _ = require("lodash");
require("dotenv").config();

const TOKEN_EXPIRE_IN = process.env.TOKEN_EXPIRE_IN;
const APP_SECRET = process.env.APP_SECRET;

module.exports.generateHashPassword = (password) => {
  const salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(password, salt);
};

module.exports.verifyPassword = (password, hashedPassword) => {
  return bcrypt.compare(password, hashedPassword);
};

module.exports.generateJWTToken = (data) => {
  const token = jwt.sign(data, APP_SECRET, { expiresIn: TOKEN_EXPIRE_IN });
  return token;
};

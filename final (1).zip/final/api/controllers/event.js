const { default: mongoose } = require("mongoose");
const db = require("../models");
const _ = require("lodash");

const eventsModel = db.events;
const userFavouriteEventsModel = db.user_favourite_events;

// module.exports.create = async (req, res) => {
//   try {
//     const { title, description, date, location, price, category } = req?.body;
//     const EventImage = req?.file;

//     const newEvent = {
//       title,
//       description,
//       date,
//       location,
//       price,
//       image: EventImage?.filename,
//       category,
//     };

//     const createEvent = await eventsModel
//       .create(newEvent)
//       .then(() => {
//         return { status: true, messsage: "Event created successfully." };
//       })
//       .catch((error) => {
//         return { status: false, message: error?.message };
//       });

//     return res.status(200).send(createEvent);
//   } catch (error) {
//     return res.status(500).send({ status: false, message: error?.message });
//   }
// };

module.exports.create = async (req, res) => {
  try {
    const {
      title,
      description,
      date,
      location,
      price,
      category,
      spanishTitle,
      spanishDescription,
    } = req?.body;
    const EventImage = req?.file;

    const newEvent = {
      title,
      description,
      date,
      location,
      price,
      image: EventImage?.filename,
      category,
      spanishTitle,
      spanishDescription,
    };

    const createEvent = await eventsModel
      .create(newEvent)
      .then(() => {
        return { status: true, messsage: 'Event created successfully.' };
      })
      .catch(error => {
        return { status: false, message: error?.message };
      });

    return res.status(200).send(createEvent);
  } catch (error) {
    return res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.getEvents = async (req, res) => {
  try {
    const { category = "all" } = req?.body;

    let findEvents;

    if (category == "all") {
      findEvents = await eventsModel
        .find({})
        .sort({ createdAt: -1 }) // Descending order by createdAt
        .limit(25);
    } else {
      findEvents = await eventsModel
        .find({ category })
        .sort({ createdAt: -1 })
        .limit(25);
    }

    if (!_.isEmpty(findEvents)) {
      //   const updatedEvents = await Promise.all(
      //     findEvents.map(async (event) => {
      //       const isFavourite = await userFavouriteEventsModel.findOne({
      //         user_id,
      //         event_id: event._id,
      //       });

      //       // Set the isFavourite key directly
      //       event.isFavourite = !_.isNull(isFavourite);
      //       return event; // Return the modified event
      //     })
      //   );

      return res.status(200).send({
        status: true,
        data: findEvents,
        message: "Events successfully found.",
      });
    } else {
      return res
        .status(200)
        .send({ status: false, message: "No events found." });
    }
  } catch (error) {
    return res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.getEventsForLoginUsers = async (req, res) => {
  try {
    const { _id: user_id } = req?.user;
    const { category = "all" } = req?.body;

    let findEvents;

    if (category == "all") {
      findEvents = await eventsModel
        .find({})
        .sort({ createdAt: -1 }) // Descending order by createdAt
        .limit(25)
        .lean();
    } else {
      findEvents = await eventsModel
        .find({ category })
        .sort({ createdAt: -1 })
        .limit(25)
        .lean();
    }

    if (!_.isEmpty(findEvents)) {
      const updatedEvents = await Promise.all(
        findEvents.map(async (event) => {
          const isFavourite = await userFavouriteEventsModel.findOne({
            user_id,
            event_id: event._id,
          });

          event.isFavourite = !_.isNull(isFavourite) ? true : false;
          return event;
        })
      );

      return res.status(200).send({
        status: true,
        data: updatedEvents,
        message: "Events successfully found.",
      });
    } else {
      return res
        .status(200)
        .send({ status: false, message: "No events found." });
    }
  } catch (error) {
    return res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.eventDetails = async (req, res) => {
  try {
    const { event_id } = req?.body;

    const findEvent = await eventsModel.findById(event_id);

    if (!_.isEmpty(findEvent)) {
      return res.status(200).send({
        status: true,
        data: findEvent,
        message: "Event details successfully found.",
      });
    } else {
      return res
        .status(404)
        .send({ status: false, message: "Event not found." });
    }
  } catch (error) {
    return res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.like = async (req, res) => {
  try {
    const { _id: user_id } = req?.user;
    const { event_id } = req?.body;

    const findEvent = await eventsModel.findById(event_id);
    if (!_.isEmpty(findEvent)) {
      const findAlreadyLike = await userFavouriteEventsModel.findOne({
        event_id: event_id,
        user_id: user_id,
      });

      if (!_.isEmpty(findAlreadyLike)) {
        const unlikeEvent = await userFavouriteEventsModel
          .deleteOne({ _id: findAlreadyLike?._id })
          .then(() => {
            return {
              status: true,
              message: "Event successfully remove from like.",
            };
          })
          .catch((error) => {
            return { status: false, message: error?.message };
          });

        return res.status(200).send(unlikeEvent);
      } else {
        const data = {
          user_id: user_id,
          event_id: event_id,
        };

        const likeEvent = await userFavouriteEventsModel
          .create(data)
          .then(() => {
            return { status: true, message: "Event successfully liked." };
          })
          .catch((error) => {
            return { status: false, message: error?.message };
          });

        return res.status(200).send(likeEvent);
      }
    } else {
      return res
        .status(200)
        .send({ status: false, message: "Event not found." });
    }
  } catch (error) {
    return res.status(500).send({ status: false, message: error?.message });
  }
};

module.exports.search = async (req, res) => {
  try {
    const { searchVal } = req?.body;

    const findEvents = await eventsModel.find({
      $or: [
        { title: { $regex: searchVal, $options: "i" } },
        { description: { $regex: searchVal, $options: "i" } },
        { location: { $regex: searchVal, $options: "i" } },
      ],
    });

    if (!_.isEmpty(findEvents)) {
      return res.status(200).send({
        status: true,
        data: findEvents,
        message: "Events successfully found.",
      });
    } else {
      return res
        .status(200)
        .send({ status: false, message: "No events found." });
    }
  } catch (error) {
    return res.status(500).send({ status: false, message: error?.message });
  }
};

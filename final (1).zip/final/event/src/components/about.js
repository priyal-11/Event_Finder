import React, { useContext } from "react";
import { LanguageContext } from "./language";  

const translations = {
  title: { en: "About Us", es: "Sobre Nosotros" },
  content: {
    en: "Welcome to EventHub, your go-to destination for discovering and attending events that matter to you! ...",
    es: "¡Bienvenido a EventHub, tu destino para descubrir y asistir a eventos que importan para ti! ..."
  },
  team: { en: "Team Members:", es: "Miembros del equipo:" },
  members: {
    en: ["Priyal Shah - Designer", "Mit Pandya - Developer", "Justin Akagha - Designer", "Loz Yarbrough - Designer"],
    es: ["Priyal Shah - Diseñadora", "Mit Pandya - Desarrollador", "Justin Akagha - Diseñador", "Loz Yarbrough - Diseñador"]
  },
};

const About = () => {
  const { language } = useContext(LanguageContext);

  return (
    <div style={{ padding: "20px" }}>
      <h1 style={{ textAlign: "center", color: "green" }}>{translations.title[language]}</h1>
      <p>{translations.content[language]}</p>
      <p>{translations.team[language]}</p>
      {translations.members[language].map((member, index) => (
        <p key={index}>{member}</p>
      ))}
    </div>
  );
};

export default About;

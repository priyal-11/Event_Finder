const router = require("express").Router();
const userAuth = require("../middlewares/auth");
const multer = require("../middlewares/multer");

const eventController = require("../controllers/event");

router.post(
  "/create",
  userAuth,
  multer.uploadImg.single("event_image"),
  eventController.create
);
router.post("/get-events", eventController.getEvents);
router.post("/get-events-for-login-users", userAuth, eventController.getEventsForLoginUsers);
router.post("/event-detail", eventController.eventDetails);
router.post("/like", userAuth, eventController.like);
router.post("/search", userAuth, eventController.search);

module.exports = router;

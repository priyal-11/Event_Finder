import React, { useContext, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { LanguageContext } from "./language"; // Import the LanguageContext
import "./userdashboard.css";
import axios from "axios";
import { useSelector } from "react-redux";

const translations = {
  title: {
    en: "User Dashboard",
    es: "Panel de Usuario",
  },
  eventName: {
    en: "Event Name",
    es: "Nombre del Evento",
  },
  dateTime: {
    en: "Date / Time",
    es: "Fecha / Hora",
  },
  location: {
    en: "Location",
    es: "Ubicación",
  },
  tickets: {
    en: "No. of Tickets",
    es: "No. de Entradas",
  },
  price: {
    en: "Price",
    es: "Precio",
  },
  confirmPay: {
    en: "Confirm to Pay",
    es: "Confirmar Pago",
  },
  deleteIcon: {
    en: "Delete",
    es: "Eliminar",
  },
  tabs: {
    en: { pending: "Pending Payment", complete: "Booked Events" },
    es: { pending: "Pago Pendiente", complete: "Evento Reservado" },
  },
};

const UserDashboard = () => {
  const { language } = useContext(LanguageContext); // Access the language from the context
  const { state } = useLocation(); // Get passed state from the previous page
  const navigate = useNavigate();
  const token = useSelector((state) => state.auth.token);
  const [purchaseData, setPurchaseData] = useState([]);
  const [selectedTab, setSelectedTab] = useState("pending"); // Track selected tab
  const [selectedEvents, setSelectedEvents] = useState([]); // Track selected events for booking

  // Delete event handler
  const handleDelete = async (history_id) => {
    try {
      const response = await axios.post(
        `http://localhost:5000/purchase/delete`,
        { history_id },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response?.data?.status) {
        
        window.location.reload(); 
        fetchPurchaseHistory();
      } else {
            
      }
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };

  // Navigate to the Payment Page
  const handleConfirmPay = () => {
    if (selectedEvents.length === 0) {
      console.error("Please select at least one event to book.");
      return;
    }

    navigate("/payment", { state: { eventIds: selectedEvents } });
  };

  const fetchPurchaseHistory = async () => {
    try {
      const response = await axios.get(
        `http://localhost:5000/purchase/history/${selectedTab}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (response?.data?.status) {
        setPurchaseData(response.data.data);
      } else {
        console.error(response.data.message);
      }
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };

  const filteredData = purchaseData.filter((item) =>
    selectedTab === "pending"
      ? !item.is_payment_complete
      : item.is_payment_complete
  );

  // Handle checkbox change for selecting events
  const handleCheckboxChange = (eventId) => {
    setSelectedEvents(
      (prevSelected) =>
        prevSelected.includes(eventId)
          ? prevSelected.filter((event_id) => event_id !== eventId) // Uncheck
          : [...prevSelected, eventId] // Check
    );
  };

  useEffect(() => {
    if (token) {
      fetchPurchaseHistory();
    }
  }, [token, selectedTab]);

  const handleTabChange = (type) => {
    setSelectedTab(type); // Set the tab state; fetchPurchaseHistory will run via useEffect
  };

  return (
    <div className="user-dashboard-container">
      <h1 className="page-title">{translations.title[language]}</h1>
      {/* Tab Navigation */}
      <div className="tab-container">
        <button
          className={`tab ${selectedTab === "pending" ? "active-tab" : ""}`}
          onClick={() => handleTabChange("pending")}
        >
          {translations.tabs[language].pending}
        </button>
        <button
          className={`tab ${selectedTab === "complete" ? "active-tab" : ""}`}
          onClick={() => handleTabChange("complete")}
        >
          {translations.tabs[language].complete}
        </button>
      </div>

      <table className="dashboard-table">
        <thead>
          <tr>
            <th></th> {/* Checkbox column */}
            <th>{translations.eventName[language]}</th>
            <th>{translations.dateTime[language]}</th>
            <th>{translations.location[language]}</th>
            <th>{translations.tickets[language]}</th>
            <th>{translations.price[language]}</th>
            {selectedTab === "pending" && (
              <th>{translations.deleteIcon[language]}</th>
            )}
          </tr>
        </thead>
        <tbody>
          {filteredData.map((purchase_history) => (
            <tr key={purchase_history._id}>
              <td>
                {selectedTab === "pending" && (
                  <input
                    type="checkbox"
                    checked={selectedEvents.includes(purchase_history.event_id)}
                    onChange={() =>
                      handleCheckboxChange(purchase_history.event_id)
                    }
                  />
                )}
              </td>
              <td>{language == 'es' ? purchase_history.spanishTitle : purchase_history.title}</td>
              <td>{purchase_history.date}</td>
              <td>{purchase_history.location}</td>
              <td>{purchase_history.person}</td>
              <td>
                ${Number(purchase_history.price.$numberDecimal).toFixed(2)}
              </td>
              <td>
                {selectedTab === "pending" && (
                  <button
                    className="delete-button"
                    onClick={() => handleDelete(purchase_history._id)}
                  >
                    🗑
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedTab === "pending" && (
        <>
          <div className="confirm-pay-button-container">
            <button className="confirm-pay-button" onClick={handleConfirmPay}>
              {translations.confirmPay[language]}
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default UserDashboard;

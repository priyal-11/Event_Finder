import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import axios from "axios";
import { useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import './payment.css';

const PaymentPage = () => {
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState(null);
  const [cvv, setCvv] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const token = useSelector((state) => state.auth.token);
  const location = useLocation();

  const { eventIds } = location.state || {};

  const validateCardNumber = (value) => {
    if (/^\d{0,16}$/.test(value)) setCardNumber(value);
  };

  const validateCvv = (value) => {
    if (/^\d{0,3}$/.test(value)) setCvv(value);
  };

  const validatePostalCode = (value) => {
    if (/^\d{0,5}$/.test(value)) setPostalCode(value);
  };

  const handleSubmit = async(e) => {
    e.preventDefault();

    if (cardNumber.length !== 16) {
      setError('Card number must be 16 digits.');
      return;
    }
    if (!expiryDate) {
      setError('Please select a valid expiry date.');
      return;
    }
    if (cvv.length !== 3) {
      setError('CVV must be 3 digits.');
      return;
    }
    if (postalCode.length !== 5) {
      setError('Postal code must be 5 digits.');
      return;
    }

    setError('');
    const response = await axios.post(
      "http://localhost:5000/purchase/book-events",
      { event_ids: eventIds },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response?.data?.status) {
      navigate("/payment-success");
    } else {
      setError(response?.data?.message || "An error occurred while processing your payment.");
    }
  };

  return (
    <div className="payment-container">
      <h1 className="payment-title">Payment Method</h1>

      <div className="payment-options">
        <div className="payment-methods">
          <button className="apple-pay-btn">
            <img src="/images/apple-pay.jpg" alt="Apple Pay" />
          </button>
          <span className="or-divider">OR</span>
          <button className="google-pay-btn">
            <img src="/images/google-pay.jpg" alt="Google Pay" />
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="payment-details">
          <h3>Payment Details</h3>

          <input
            type="text"
            placeholder="CARD NUMBER"
            className="payment-input"
            value={cardNumber}
            onChange={(e) => validateCardNumber(e.target.value)}
            required
          />

          <div className="card-details">
            <DatePicker
              selected={expiryDate}
              onChange={(date) => setExpiryDate(date)}
              dateFormat="MM/yy"
              showMonthYearPicker
              placeholderText="MM/YY"
              className="payment-input"
            />

            <input
              type="text"
              placeholder="CVV"
              className="payment-input"
              value={cvv}
              onChange={(e) => validateCvv(e.target.value)}
              required
            />
            <input
              type="text"
              placeholder="POSTAL CODE"
              className="payment-input"
              value={postalCode}
              onChange={(e) => validatePostalCode(e.target.value)}
              required
            />
          </div>
        </div>

        {error && <p className="error-message">{error}</p>}

        <button type="submit" className="pay-button">
          Pay
        </button>
      </form>
    </div>
  );
};

export default PaymentPage;

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { join } = require("path");
require("dotenv").config();

const { connectToDatabase } = require("./config");

const HOST_URL = process.env.HOST_URL;
const HOST_PORT = process.env.HOST_PORT;

const app = express();

app.use(cors());
app.options("*", cors());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const publicFolders = [join(process.cwd(), "uploads", ".tmp")];

// Serve static files from each public folder
publicFolders.forEach((publicFolder) => {
  app.use(express.static(publicFolder));
});

// Connect to the database
connectToDatabase();

// Define the routes
const userRoute = require("./routes/user");
const eventRoute = require("./routes/event");
const purchaseRoute = require("./routes/purchase");

app.use("/users", userRoute);
app.use("/events", eventRoute);
app.use("/purchase", purchaseRoute);

app.use("/", (req, res) => {
  return res.json({ message: "Welcome to Event Finder." });
});

app.listen(HOST_PORT, () => {
  console.log(`Server is running on http://${HOST_URL}:${HOST_PORT}`);
});

import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LanguageContext } from "./language";
import "./navbar.css";
import { useSelector, useDispatch } from "react-redux";
import { clearToken } from "../redux/authSlice";

const translations = {
  purchasedTickets: { en: "Purchased Tickets", es: "Entradas Compradas" },
  login: { en: "Login", es: "Iniciar Sesión" },
  signUp: { en: "Sign Up", es: "Regístrate" },
  logout: { en: "Logout", es: "Cerrar Sesión" },
  EventFinder: { en: "EventFinder", es: "Buscador de eventos" },
  CreateEvent:{en:"Create Event",es:"Crear evento"}
};

const Navbar = () => {
  const { language } = useContext(LanguageContext);
  const token = useSelector((state) => state.auth.token);
  const isAdmin = useSelector((state) => state.auth.isAdmin);
  const dispatch = useDispatch();
  const navigate = useNavigate();


  const handleLogout = () => {
    dispatch(clearToken());
    navigate("/");
  };

  const handleCreateEvent = (e) => {
    e.preventDefault();
    navigate("/create-event");
  };

  return (
    <nav className="navbar">
      <Link to="/" className="logo">{translations.EventFinder[language]}</Link>

      <div className="nav-links">
        {!token ? (
          <>
            <Link to="/login" className="nav-button">
              {translations.login[language]}
            </Link>
            <Link to="/signup" className="nav-button">
              {translations.signUp[language]}
            </Link>
          </>
        ) : (
          <>
            {isAdmin && (
              <button onClick={handleCreateEvent} className="nav-button">
               {translations.CreateEvent[language]}
              </button>
            )}
            <Link to="/user-dashboard" className="nav-button">
              {translations.purchasedTickets[language]}
            </Link>
            <button onClick={handleLogout} className="nav-button">
              {translations.logout[language]}
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;

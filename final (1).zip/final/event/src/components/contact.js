import React, { useContext } from "react";
import { LanguageContext } from "./language";

const translations = {
  title: { en: "Contact Us", es: "Contáctanos" },
  intro: {
    en: "We are here to help! ...",
    es: "¡Estamos aquí para ayudar! ..."
  },
  email: { en: "Email: support@eventfinderapp.com", es: "Correo electrónico: soporte@eventfinderapp.com" },
  phone: { en: "Phone: +1 (445)-567-890", es: "Teléfono: +1 (445)-567-890" },
  address: {
    en: "Address: University of North Carolina at Charlotte.",
    es: "Dirección: Universidad de Carolina del Norte en Charlotte."
  },
  outro: {
    en: "We look forward to hearing from you ...",
    es: "Esperamos tener noticias tuyas ..."
  },
};

const Contact = () => {
  const { language } = useContext(LanguageContext);

  return (
    <div style={{ padding: "20px" }}>
      <h1>{translations.title[language]}</h1>
      <p>{translations.intro[language]}</p>
      <p>{translations.email[language]}</p>
      <p>{translations.phone[language]}</p>
      <p>{translations.address[language]}</p>
      <p>{translations.outro[language]}</p>
    </div>
  );
};

export default Contact;

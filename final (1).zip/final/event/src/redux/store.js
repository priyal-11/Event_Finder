import { configureStore } from "@reduxjs/toolkit";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage"; // default to localStorage for web
import authReducer from "./authSlice";
import { combineReducers } from "redux";

// Configuration for persistence
const persistConfig = {
  key: "root",
  storage,
  whitelist: ["auth"], // Only auth slice will be persisted
};

// Combine reducers (useful if you plan to add more reducers later)
const rootReducer = combineReducers({
  auth: authReducer,
});

// Create a persisted reducer
const persistedReducer = persistReducer(persistConfig, rootReducer);

// Configure store with persisted reducer
const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

const persistor = persistStore(store);

export { store, persistor };

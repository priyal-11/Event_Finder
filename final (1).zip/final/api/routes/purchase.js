const router = require("express").Router();
const userAuth = require("../middlewares/auth");

const purchaseController = require("../controllers/purchase");

router.post("/purchase", userAuth, purchaseController.purchase);
router.get("/history/:type", userAuth, purchaseController.getPurchaseHistory);
router.post("/delete", userAuth, purchaseController.delete);
router.post("/book-events", userAuth, purchaseController.bookEvents)

module.exports = router;
